package com.pizzaking.service;

import com.pizzaking.bean.Customer;

public interface IPizzaOrderService {

	public void placeOrder();
	public Customer getOrderdetails(int orderid);
}
