package com.pizzaking.service;


import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

import com.pizzaking.bean.Bill;
import com.pizzaking.bean.Customer;
import com.pizzaking.bean.PizzaOrder;

import com.pizzaking.dao.PizzaOrderDao;



public class PizzaOrderService {

	PizzaOrderDao pizzaorderd=new PizzaOrderDao();
	Bill bl=new Bill();
	PizzaOrder pz=new PizzaOrder();
	Customer cs=new Customer();

		public void placeOrder()
	{
Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter Your Name");
		String name=sc.next();
		
		System.out.println("Enter Your Address ");
		String addrs=sc.next();
		
		System.out.println("Enter Your Mobile No");
		String mobno=sc.next();
		
		System.out.println("Type of Pizza Topping Preffered ");
		System.out.println("Type the Name");
		System.out.println("1.capsicum");
		System.out.println("2.paneer");
		System.out.println("3.jalepino");
		
		
		String toping=sc.next();
		
		System.out.println("Choose Your Pizza");
		
		//Display pizza list to customer
		pizzaorderd.displayPizzaDetail();
		
		
		System.out.println("Enter your pizza No");
		int n1=sc.nextInt();
		
		int id,id1;
		id=(int)(Math.random()*10000);//calculating random order id
		
		id1=(int)(Math.random()*10000);
		bl.setOrderId(id);
		
		pz= pizzaorderd.getPizzaDetail(n1);
		
System.out.println("You Have Successfully Purchased "+pz.getPizzaname()+" And Order ID Is "+bl.getOrderId());
		

			
			//setting all details in customer object
			cs.setCustId(id1);
			cs.setCustomerName(name);
			cs.setCustAddrs(addrs);
			cs.setCustMoNo(mobno);
			cs.setToping(toping);
			
			if(toping.equals("capsicum"))
			{
				cs.setPizzaprice(pz.getPizzaprice()+30);
			}
			else if(toping.equals("paneer"))
			{
				cs.setPizzaprice(pz.getPizzaprice()+50);
			}
			else if(toping.equals("jalepino"))
			{
				cs.setPizzaprice(pz.getPizzaprice()+70);
			}
			cs.setPizza(pz.getPizza());
			cs.setPizzaname(pz.getPizzaname());
			
			cs.setOrderId(bl.getOrderId());
			
			Date date=new Date();
			SimpleDateFormat sd=new SimpleDateFormat("dd/MM/yyyy");
			String strdate=sd.format(date);
			
			cs.setPurchasedate(strdate);
			
			
			//rp.setPricewithgst(MB.getMobileprice() + (MB.getMobileprice() * 0.05f));
			cs.setTotalPrice(pz.getPizzaprice());
	
			
			pizzaorderd.storeIntoMap(cs);//store all details of customer in map
			
			
			

	}
	
	
//getting all detail from map
	public Customer getOrderdetails(int orderid) {
		
		Customer rpc=pizzaorderd.getDetailFromMap(orderid);
		return rpc;
	}



	
	
	

}
