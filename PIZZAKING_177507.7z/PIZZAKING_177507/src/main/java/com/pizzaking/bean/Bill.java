package com.pizzaking.bean;

public class Bill extends PizzaOrder
{


	
	int orderId;
	double TotalPrice;
	String purchasedate;
	
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public double getTotalPrice() {
		return TotalPrice;
	}
	public void setTotalPrice(double totalPrice) {
		TotalPrice = totalPrice;
	}
	public String getPurchasedate() {
		return purchasedate;
	}
	public void setPurchasedate(String purchasedate) {
		this.purchasedate = purchasedate;
	}
	@Override
	public String toString() {
		return "Bill [orderId=" + orderId + ", TotalPrice=" + TotalPrice + ", purchasedate=" + purchasedate + "]";
	}

	public void Bill() {
		// TODO Auto-generated constructor stub
	}
}
