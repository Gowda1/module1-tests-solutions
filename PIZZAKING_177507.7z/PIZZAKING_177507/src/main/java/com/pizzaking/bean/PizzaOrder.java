package com.pizzaking.bean;

public class PizzaOrder 
{
	
	 int pizza;
	String pizzaname;
	double pizzaprice;
	public int getPizza() {
		return pizza;
	}
	public void setPizza(int pizza) {
		this.pizza = pizza;
	}
	public String getPizzaname() {
		return pizzaname;
	}
	public void setPizzaname(String pizzaname) {
		this.pizzaname = pizzaname;
	}
	public double getPizzaprice() {
		return pizzaprice;
	}
	public void setPizzaprice(double pizzaprice) {
		this.pizzaprice = pizzaprice;
	}
	
	
	public PizzaOrder(int pizza, String pizzaname, double pizzaprice) {
	
		this.pizza = pizza;
		this.pizzaname = pizzaname;
		this.pizzaprice = pizzaprice;
	}
	public PizzaOrder() {
		
	}
	@Override
	public String toString() {
		return ""
	
				
				+"pizza=" + pizza
				+ "\n pizzaname=" + pizzaname
				+ "\n pizzaprice=" + pizzaprice+"\n";
	}
	
	

}
