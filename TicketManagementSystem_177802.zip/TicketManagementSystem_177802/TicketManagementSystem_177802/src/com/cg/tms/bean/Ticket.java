package com.cg.tms.bean;

public class Ticket 
{
	private int ticketNumber;
	private String ticketCategory;
	private String ticketDescription;
	private String ticketPriority;
	private String ticketStatus;
	
	public int getTicketNumber() 
	{
		return ticketNumber;
	}
	
	public void setTicketNumber(int ticketNumber) 
	{
		this.ticketNumber = ticketNumber;
	}
	
	public String getTicketCategory() 
	{
		return ticketCategory;
	}

	public void setTicketCategory(String ticketCategory) 
	{
		this.ticketCategory = ticketCategory;
	}
	
	public String getTicketDescription() 
	{
		return ticketDescription;
	}
	
	public void setTicketDescription(String ticketDescription) 
	{
		this.ticketDescription = ticketDescription;
	}
	
	public String getTicketPriority() 
	{
		return ticketPriority;
	}
	
	public void setTicketPriority(String ticketPriority2)
	{
		this.ticketPriority = ticketPriority2;
	}
	
	public String getTicketStatus() 
	{
		return ticketStatus;
	}
	
	public void setTicketStatus(String ticketStatus)
	{
		this.ticketStatus = ticketStatus;
	}
	
}
