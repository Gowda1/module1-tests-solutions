package com.cg.tms.ui;

import java.util.Scanner;

import com.cg.tms.service.TicketManagementSystem;

public class MainUI
{
	public static void main(String[] args) 
	{
		TicketManagementSystem ticketManagementSystem = new TicketManagementSystem();
		Scanner input = new Scanner(System.in);
		
		while (true) 
		{
			System.out.println("********Welcome to ITIMD Help Desk**********");
			System.out.println("1. Raise a Ticket");
			System.out.println("2. Exit from the System");
			
			System.out.print("\n Enter Your Choice: ");
			int userInput = input.nextInt();
			
			if(userInput == 1) 
			{
				ticketManagementSystem.raiseTicket(); 
				break;
			}
			
			else if(userInput == 2)
				break;
			
			else
				System.out.println("\nNot a valid option!!!!, Try again.\n");		
		}
	}
}
