package com.cg.tms.service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;
import java.util.Scanner;
import java.util.function.Supplier;

import com.cg.tms.bean.Ticket;
import com.cg.tms.dao.Database;

public class TicketManagementSystem 
{
	Database db = new Database();
	Scanner input = new Scanner(System.in);
	Ticket ticket = new Ticket();
	Random random = new Random();
	
	int ticketNumber;
	int categoryNumber;
	String ticketDescription;
	int ticketPriorityNumber;
	String ticketPriority;
	
	//Generating 4 digit random number
	Supplier<Integer> randomNumber = () -> 
	{
		return random.nextInt((9999 - 1000) + 1) + 1000;
	};
	
	public void raiseTicket() 
	{
		ticketNumber = randomNumber.get();
		
		//Check If Generated Random Number Already Exists
		while(db.checkTicketNumberALreadyExist(ticketNumber))
		{
			ticketNumber = randomNumber.get();
		}	
		
		//Display all Ticket category
		System.out.println("\nSelect Ticket Category from below List:\n");
		db.getAllCategories();
		
		//Get Category information form user
		System.out.print("\nEnter Option: ");
		categoryNumber = input.nextInt();
		if(categoryNumber >= 1 && categoryNumber <= 3)
		{
			ticket.setTicketCategory(db.getCategory(categoryNumber));
		}
		
		//Get Ticket description information from user
		System.out.println("\nEnter Description related to issue:");
		ticketDescription = input.next();
		ticket.setTicketDescription(ticketDescription);
		
		//Get Ticket Priority information from user 
		System.out.print("\nEnter Priority [| 1.Low | 2.Medium | 3.High |]: ");
		ticketPriorityNumber = input.nextInt();
		
		//Setting Ticket Priority Based on User Input
		if(ticketPriorityNumber == 1)
			ticketPriority = "Low";
		
		else if(ticketPriorityNumber == 2)
			ticketPriority = "Medium";
		
		else if(ticketPriorityNumber == 3)
			ticketPriority = "High";	
		ticket.setTicketPriority(ticketPriority);
		
		//Set Ticket Status
		ticket.setTicketStatus("NEW");
	
		//Store into TicketLog database
		db.storeIntoTicketLog(ticketNumber, ticket);
		
		//Format date
		Date CurrentDate = new Date();
		DateFormat dateFormat = new SimpleDateFormat("dd MMMM yyyy HH:mm a"); 
		
		System.out.println("\nTicket Number " + ticketNumber + " logged Successfully at " + dateFormat.format(CurrentDate));
	}
}
